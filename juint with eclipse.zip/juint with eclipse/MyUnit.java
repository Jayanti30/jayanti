public class MyUnit {

	public String stringConcat(String a, String b) {
		return a + b;
	}

}