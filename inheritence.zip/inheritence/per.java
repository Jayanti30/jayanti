public class per {
	private String name;
}