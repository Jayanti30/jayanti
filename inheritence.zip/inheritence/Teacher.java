public class Teacher extends Person {
	private int salary;
	private String subject;
}