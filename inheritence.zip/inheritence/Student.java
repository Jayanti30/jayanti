public class Student extends per {
	private int roll;
}