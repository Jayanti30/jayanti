public class CollegeStudent extends Student {
	private int year;
	private String major;

public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}