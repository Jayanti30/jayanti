import java.io.*;
class c12
{
public static void main(String[] args)throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int n,i,c=0;
System.out.println("Enter a number:");
n=Integer.parseInt(br.readLine());
for(i=2;i<=n;i+=1)
{
if(n%i==0)
c=c+1;
}
if(c==1)
System.out.println("prime");
else
System.out.println("not prime");
}}


