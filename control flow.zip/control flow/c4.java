class c4
{
public static void main(String args[])
{
char a='x';
char b='t';
if(a<b)
System.out.println(a+", "+b);
else
System.out.println(b+", "+a);
}
}