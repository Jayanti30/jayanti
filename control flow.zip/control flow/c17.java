import java.io.*;
class c17
{
public static void main(String[] args)throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int n=Integer.parseInt(br.readLine());
int d,r=0;
int z=n;
while(z!=0)
{
d=z%10;
r=r*10+d;
z=z/10;
}
System.out.println(r);
}
}