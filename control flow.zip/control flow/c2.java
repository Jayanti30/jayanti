import java.io.*;
class c2
{
public static void main(String[] args)throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int n;
System.out.print("enter a number:");
n=Integer.parseInt(br.readLine());
if(n%2==0)
System.out.println("even");
else
System.out.println("odd");
main(args);
br.close();


}
}
