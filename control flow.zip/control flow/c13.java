class c13
{
public static void main(String[] args)
{
int i,k;
for(i=10;i<=99;i++)
{
int c=0;
for(k=2;k<=i;k++)
{
if(i%k==0)
c+=1;
}
if(c==1)
System.out.print(i+" ");
}
}
}