class c10
{
public static void main(String[] args)
{
int i;
for(i=1;i<=10;i+=1)
System.out.print(i+"\t");

}
}