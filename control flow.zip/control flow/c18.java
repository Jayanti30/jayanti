class c18
{
public static void main(String[] args)
{
int no=Integer.parseInt(args[0]);
int d,r=0;
int z=no;
while(z!=0)
{
d=z%10;
r=r*10+d;
z=z/10;
}
if(r==no)
System.out.println(no+" is a pallindrome");
else
System.out.println(no+" is not a pallindrome");
}
}