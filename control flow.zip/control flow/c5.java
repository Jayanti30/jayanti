class c5
{
public static void main(String args[])
{
char d='$';
int k=d;
if((k>=65&&k<=90)||(k<=122&&k>=97))
System.out.println("Alphabet");
else if(k<=57&&k>=48)
System.out.println("Digit");
else
System.out.println("Special Character");
}
}