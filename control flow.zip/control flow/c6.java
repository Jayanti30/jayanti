class c6
{
public static void main(String[] args) 
{
String g = args[0];
int a = Integer.parseInt(args[1]);
if (!g.equals("Male") && !g.equals("Female"))
System.out.println("Invalid gender");
if (a < 1 || a >= 120)
System.out.println("Invalid age");
if (g.equals("Female") && (a >= 1 && a <= 58)) 
System.out.println("Interest =8.2%");
 else if (g.equals("Female") && (a >= 59 && a <= 120)) 
System.out.println("Interest = 7.6%");
 else if (g.equals("Male") && (a >= 1 && a <= 60)) 
System.out.println("Interest = 9.2%");
 else if (g.equals("Male") && (a >= 61 && a <= 120)) 
System.out.println("Interest =8.3%");
}
}


