import java.io.*;
class c8
{
public static void main(String args[])throws IOException
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
char a;
a=(char)br.read();
switch(a)
{
case 'R':
System.out.println("Red");
break;
case'B':
System.out.println("Blue");
break;
case 'G':
System.out.println("Green");
break;
case 'O':
System.out.println("Orange");
break;
case'Y':
System.out.println("Yellow");
break;
case'W':
System.out.println("White");
default:
System.out.println("Invalid Code");
}
}
}
