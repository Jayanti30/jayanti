class box {
	double width;
	double height;
	double depth;
	
	 public box(double width, double height, double depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}
	
	public double getVolume() {
		double v= width * height * depth;
                                    return v;
	}



	public static void main(String[] args) {
		box b = new box(16, 9, 4);
		System.out.println(b.getVolume());
	}

}
