class a1
{
public static void main(String[] args)
{
int[] a = {5, 4, 3, 9, 1, 7, 9};
double sum = 0;
double avg;
for (int i = 0; i < a.length; i++) 
{
sum += a[i];
}
avg = sum / a.length;
System.out.println("sum: "+sum);
System.out.println("Average: " + avg);
}
}