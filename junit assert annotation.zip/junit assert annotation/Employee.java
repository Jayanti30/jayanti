import java.util.ArrayList;
import static org.junit.Assert.*;
import org.junit.jupiter.api.Test;

public class Employee {
	
	public String findName(ArrayList<String> employees, String name){
		String result = "";
		
		if(employees.contains(name)){
			result="FOUND";
		} else {
			result="NOT FOUND";
		}
		
		return result;
	}
void testFindName() {
		System.out.println(list);
		assertEquals("Result", "FOUND", e.findName(list, "Alice"));
		System.out.println("test");
	}


	public static void main(String[] args)
{
Employee e = new Employee();
	ArrayList<String> list = new ArrayList<>();
	{
		list.add("Bob");
		list.add("Alice");
		list.add("John");
	
}
}
}
