import java.util.*;
public class s11
{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        String s2[]=s1.split(",");
        String s3=s2[0];
        String s4=s2[1];
        String s5="";
        for(int i=1;i<s3.length()-1;i++)
        {
        if(s3.charAt(i)==s4.charAt(0))
        {
            s5=s5+s3.charAt(i-1);
        }
        else if(s3.charAt(i)==s4.charAt(s4.length()-1))
        {
        s5=s5+s3.charAt(i+1);
        }
        }
         System.out.println(s5);
        
        }
    }
