class s10
{
public static void main(String[] args)
{
String s="Wipro";
int n=3;
int l=s.length();
String w=s.substring(n-1,l);
for(int i=1;i<=n;i++)
{
System.out.print(w);
}
}
}